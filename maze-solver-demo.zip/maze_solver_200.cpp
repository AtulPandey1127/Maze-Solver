#include <iostream>
#include <vector>
#include <stack>
#include <queue>
#include <random>

class MazeSolver {
private:
    std::vector<std::vector<int>> maze;
    int rows, cols;
    std::pair<int, int> start, end;

    void generateMaze() {
        maze.assign(rows, std::vector<int>(cols, 1));
        std::vector<std::vector<bool>> visited(rows, std::vector<bool>(cols, false));

        std::random_device rd;
        std::mt19937 gen(rd());

        int startX = 1, startY = 1;
        maze[startX][startY] = 0;
        visited[startX][startY] = true;

        std::stack<std::pair<int, int>> stack;
        stack.push({startX, startY});

        std::vector<std::pair<int, int>> dirs = {{-2, 0}, {0, 2}, {2, 0}, {0, -2}};

        while (!stack.empty()) {
            auto [x, y] = stack.top();

            std::vector<int> unvisited;
            for (int i = 0; i < 4; i++) {
                int nx = x + dirs[i].first, ny = y + dirs[i].second;
                if (nx > 0 && nx < rows-1 && ny > 0 && ny < cols-1 && !visited[nx][ny]) {
                    unvisited.push_back(i);
                }
            }

            if (!unvisited.empty()) {
                int dir = unvisited[gen() % unvisited.size()];
                int nx = x + dirs[dir].first, ny = y + dirs[dir].second;
                int wallX = x + dirs[dir].first/2, wallY = y + dirs[dir].second/2;

                maze[wallX][wallY] = maze[nx][ny] = 0;
                visited[nx][ny] = true;
                stack.push({nx, ny});
            } else {
                stack.pop();
            }
        }

        start = {1, 1};
        end = {rows-2, cols-2};
    }

    bool solveDFS(int x, int y, std::vector<std::vector<int>>& sol) {
        if (x < 0 || x >= rows || y < 0 || y >= cols || maze[x][y] == 1 || sol[x][y] == 1)
            return false;

        sol[x][y] = 1;

        if (x == end.first && y == end.second) return true;

        if (solveDFS(x+1, y, sol) || solveDFS(x-1, y, sol) || 
            solveDFS(x, y+1, sol) || solveDFS(x, y-1, sol))
            return true;

        sol[x][y] = 0;
        return false;
    }

    bool solveBFS(std::vector<std::vector<int>>& sol) {
        std::vector<std::vector<bool>> visited(rows, std::vector<bool>(cols, false));
        std::vector<std::vector<std::pair<int, int>>> parent(rows, 
            std::vector<std::pair<int, int>>(cols, {-1, -1}));

        std::queue<std::pair<int, int>> q;
        q.push(start);
        visited[start.first][start.second] = true;

        std::vector<std::pair<int, int>> dirs = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};

        while (!q.empty()) {
            auto [x, y] = q.front();
            q.pop();

            if (x == end.first && y == end.second) {
                int px = x, py = y;
                while (px != -1 && py != -1) {
                    sol[px][py] = 1;
                    auto [npx, npy] = parent[px][py];
                    px = npx; py = npy;
                }
                return true;
            }

            for (auto [dx, dy] : dirs) {
                int nx = x + dx, ny = y + dy;
                if (nx >= 0 && nx < rows && ny >= 0 && ny < cols && 
                    maze[nx][ny] == 0 && !visited[nx][ny]) {
                    visited[nx][ny] = true;
                    parent[nx][ny] = {x, y};
                    q.push({nx, ny});
                }
            }
        }
        return false;
    }

public:
    MazeSolver(int r, int c) : rows(r % 2 ? r : r+1), cols(c % 2 ? c : c+1) {
        generateMaze();
    }

    void printMaze() {
        std::cout << "\nGenerated Maze:\n";
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                char ch = '.';
                if (i == start.first && j == start.second) ch = 'S';
                else if (i == end.first && j == end.second) ch = 'E';
                else if (maze[i][j] == 1) ch = '#';
                std::cout << ch << ' ';
            }
            std::cout << '\n';
        }
    }

    void solveMaze(bool useBFS = false) {
        std::vector<std::vector<int>> solution(rows, std::vector<int>(cols, 0));

        std::cout << "\nSolving with " << (useBFS ? "BFS (shortest path)" : "DFS") << "...\n";

        bool found = useBFS ? solveBFS(solution) : solveDFS(start.first, start.second, solution);

        if (found) {
            std::cout << "Solution found:\n";
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    char ch = '.';
                    if (i == start.first && j == start.second) ch = 'S';
                    else if (i == end.first && j == end.second) ch = 'E';
                    else if (maze[i][j] == 1) ch = '#';
                    else if (solution[i][j] == 1) ch = '*';
                    std::cout << ch << ' ';
                }
                std::cout << '\n';
            }
        } else {
            std::cout << "No solution found!\n";
        }
    }

    void runDemo() {
        printMaze();
        solveMaze(false);  // DFS
        solveMaze(true);   // BFS
    }

    // Method to solve custom maze
    static void solveCustomMaze() {
        int rows, cols;
        std::cout << "Enter maze dimensions (rows cols): ";
        std::cin >> rows >> cols;

        std::vector<std::vector<int>> customMaze(rows, std::vector<int>(cols));
        std::cout << "Enter maze (0=path, 1=wall):\n";
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                std::cin >> customMaze[i][j];
            }
        }

        int startX, startY, endX, endY;
        std::cout << "Enter start position (row col): ";
        std::cin >> startX >> startY;
        std::cout << "Enter end position (row col): ";
        std::cin >> endX >> endY;

        std::vector<std::vector<int>> solution(rows, std::vector<int>(cols, 0));

        std::function<bool(int, int)> dfs = [&](int x, int y) -> bool {
            if (x < 0 || x >= rows || y < 0 || y >= cols || 
                customMaze[x][y] == 1 || solution[x][y] == 1)
                return false;

            solution[x][y] = 1;
            if (x == endX && y == endY) return true;

            if (dfs(x+1, y) || dfs(x-1, y) || dfs(x, y+1) || dfs(x, y-1))
                return true;

            solution[x][y] = 0;
            return false;
        };

        if (dfs(startX, startY)) {
            std::cout << "\nSolution found:\n";
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    if (i == startX && j == startY) std::cout << "S ";
                    else if (i == endX && j == endY) std::cout << "E ";
                    else if (customMaze[i][j] == 1) std::cout << "# ";
                    else if (solution[i][j] == 1) std::cout << "* ";
                    else std::cout << ". ";
                }
                std::cout << '\n';
            }
        } else {
            std::cout << "No solution exists!\n";
        }
    }
};

int main() {
    std::cout << "=== C++ Maze Solver Project ===\n";
    std::cout << "Features:\n";
    std::cout << "- Random maze generation using recursive backtracking\n";
    std::cout << "- Maze solving using DFS and BFS algorithms\n";
    std::cout << "- Support for custom maze input\n\n";

    std::cout << "Choose option:\n";
    std::cout << "1. Generate and solve random maze\n";
    std::cout << "2. Solve custom maze\n";
    std::cout << "Enter choice: ";

    int choice;
    std::cin >> choice;

    if (choice == 1) {
        int rows, cols;
        std::cout << "Enter maze dimensions (rows cols): ";
        std::cin >> rows >> cols;

        MazeSolver solver(rows, cols);
        solver.runDemo();
    } else if (choice == 2) {
        MazeSolver::solveCustomMaze();
    } else {
        std::cout << "Invalid choice!\n";
    }

    return 0;
}