# C++ Maze Solver Project

## Overview

This is a comprehensive C++ maze solver project that implements both maze generation and solving algorithms. The project demonstrates fundamental computer science concepts including graph traversal, backtracking, and pathfinding algorithms.

## Features

✅ **Random Maze Generation** using Recursive Backtracking algorithm  
✅ **Maze Solving** with both DFS and BFS algorithms  
✅ **Custom Maze Input** support for user-defined mazes  
✅ **Visual Output** with clear symbols (S=Start, E=End, #=Wall, *=Path)  
✅ **Modern C++17** features including structured bindings  
✅ **Clean Architecture** with modular design  

## Algorithms Implemented

### 1. Maze Generation - Recursive Backtracking
- **Time Complexity**: O(V) where V is the number of cells
- **Space Complexity**: O(V) for the call stack
- **Description**: Creates perfect mazes (no loops, single path between any two points)
- **Process**: 
  1. Start with all walls
  2. Choose random starting cell
  3. Randomly select unvisited neighbor
  4. Remove wall between current and chosen cell
  5. Recursively continue until all cells visited
  6. Backtrack when no unvisited neighbors

### 2. Maze Solving - Depth-First Search (DFS)
- **Time Complexity**: O(V + E) where V=vertices, E=edges
- **Space Complexity**: O(V) for recursion stack
- **Finds**: Any path from start to end (not necessarily shortest)
- **Advantages**: Low memory usage, simple implementation
- **Process**: Explores as far as possible along each branch before backtracking

### 3. Maze Solving - Breadth-First Search (BFS)
- **Time Complexity**: O(V + E)
- **Space Complexity**: O(V) for queue storage
- **Finds**: Shortest path from start to end
- **Advantages**: Guarantees optimal solution
- **Process**: Explores all neighbors at current depth before moving deeper

## Project Structure

```
maze_solver_ultra_compact.cpp    # Main project file (214 lines)
├── MazeSolver class            # Random maze generation and solving
├── solveCustomMaze()           # Custom maze input handling
├── quickDemo()                 # Predefined maze demonstration
└── main()                      # User interface and program flow
```

## Code Organization

- **Lines 1-5**: Headers and includes
- **Lines 6-89**: MazeSolver class with generation and solving methods
- **Lines 91-130**: Custom maze solver functionality
- **Lines 132-156**: Quick demo with predefined maze
- **Lines 158-214**: Main function and user interface

## Compilation and Usage

### Requirements
- C++17 compatible compiler (GCC 7+, Clang 5+, MSVC 2017+)
- Standard library support

### Compilation
```bash
g++ -std=c++17 maze_solver_ultra_compact.cpp -o maze_solver
```

### Running the Program
```bash
./maze_solver
```

### Usage Options

1. **Random Maze Generation**
   - Choose option 1
   - Enter desired dimensions (e.g., 15 15)
   - Program generates maze and solves with both DFS and BFS

2. **Custom Maze Input**
   - Choose option 2
   - Enter maze dimensions
   - Input maze data (0=path, 1=wall)
   - Specify start and end positions
   - Program solves using DFS

3. **Quick Demo**
   - Choose option 3
   - Runs predefined 7x7 maze example

## Example Output

### Generated Maze:
```
# # # # # # # # # 
# S . # . . . # # 
# # . # . # . . # 
# . . . . # # . # 
# . # # . . . . # 
# . . # # # # . # 
# # . . . . # . # 
# # # . # . # E # 
# # # # # # # # # 
```

### DFS Solution:
```
# # # # # # # # # 
# S * # . . . # # 
# # * # . # . . # 
# * * * . # # . # 
# * # # . . . . # 
# * . # # # # . # 
# # * * * * # . # 
# # # * # * # E # 
# # # # # # # # # 
```

## Algorithm Comparison

| Algorithm | Time Complexity | Space Complexity | Optimal Solution | Memory Usage |
|-----------|----------------|------------------|------------------|--------------|
| DFS       | O(V+E)         | O(V)             | No               | Low          |
| BFS       | O(V+E)         | O(V)             | Yes              | Medium       |

## Technical Details

### Maze Representation
- 2D vector of integers (0=path, 1=wall)
- Odd dimensions ensured for proper maze structure
- Border walls maintained for containment

### Random Number Generation
- Uses `std::random_device` for seeding
- `std::mt19937` Mersenne Twister generator
- Uniform distribution for direction selection

### Memory Management
- RAII principles with automatic memory management
- No manual memory allocation/deallocation
- Stack-based data structures where possible

## Educational Value

This project demonstrates:
- **Graph Theory**: Maze as graph representation
- **Algorithm Design**: Different approaches to pathfinding
- **Data Structures**: Stacks, queues, 2D arrays
- **Recursion**: Backtracking implementation
- **Object-Oriented Programming**: Class design and encapsulation
- **Modern C++**: Structured bindings, auto keyword, lambda functions

## Possible Extensions

1. **Additional Algorithms**: A*, Dijkstra's algorithm
2. **Maze Types**: Circular mazes, 3D mazes
3. **Visualization**: Real-time generation/solving animation
4. **File I/O**: Save/load maze configurations
5. **Performance Metrics**: Timing and path length statistics
6. **GUI Interface**: Graphical maze display

## Performance Notes

- Maze generation: Fast for typical sizes (up to 100x100)
- DFS solving: Efficient but may find longer paths
- BFS solving: Slightly more memory usage but finds shortest paths
- Recursive implementation: Stack depth limited by system

## Troubleshooting

**Compilation Issues:**
- Ensure C++17 support: `-std=c++17` flag
- Check compiler version compatibility

**Runtime Issues:**
- Large mazes may cause stack overflow with DFS
- Odd dimensions recommended for generation
- Ensure valid start/end positions for custom mazes

## Author Notes

This implementation focuses on educational clarity while maintaining efficiency. The code demonstrates fundamental algorithms that are building blocks for more complex pathfinding and graph traversal problems in computer science and game development.