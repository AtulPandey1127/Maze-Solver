// Maze Solver Application
class MazeSolver {
    constructor() {
        this.maze = [];
        this.rows = 15;
        this.cols = 15;
        this.start = { x: 1, y: 1 };
        this.end = { x: 13, y: 13 };
        this.dfsPath = [];
        this.bfsPath = [];
        this.dfsVisited = [];
        this.bfsVisited = [];
        
        this.initializeElements();
        this.bindEvents();
        this.generateMaze();
    }

    initializeElements() {
        this.generateBtn = document.getElementById('generate-maze');
        this.solveDfsBtn = document.getElementById('solve-dfs');
        this.solveBfsBtn = document.getElementById('solve-bfs');
        this.clearBtn = document.getElementById('clear-solutions');
        this.sizeSelect = document.getElementById('maze-size');
        this.mazeDisplay = document.getElementById('maze-display');
        this.dfsDisplay = document.getElementById('dfs-maze');
        this.bfsDisplay = document.getElementById('bfs-maze');
        this.dfsStats = document.getElementById('dfs-stats');
        this.bfsStats = document.getElementById('bfs-stats');
    }

    bindEvents() {
        this.generateBtn.addEventListener('click', () => this.generateMaze());
        this.solveDfsBtn.addEventListener('click', () => this.solveDFS());
        this.solveBfsBtn.addEventListener('click', () => this.solveBFS());
        this.clearBtn.addEventListener('click', () => this.clearSolutions());
        this.sizeSelect.addEventListener('change', () => this.updateMazeSize());
    }

    updateMazeSize() {
        const size = this.sizeSelect.value;
        switch(size) {
            case 'small':
                this.rows = this.cols = 11;
                break;
            case 'medium':
                this.rows = this.cols = 15;
                break;
            case 'large':
                this.rows = this.cols = 21;
                break;
        }
        this.start = { x: 1, y: 1 };
        this.end = { x: this.rows - 2, y: this.cols - 2 };
        this.generateMaze();
    }

    generateMaze() {
        // Initialize maze with walls
        this.maze = Array(this.rows).fill().map(() => Array(this.cols).fill(1));
        
        // Recursive backtracking algorithm
        const stack = [];
        const visited = Array(this.rows).fill().map(() => Array(this.cols).fill(false));
        
        const startX = 1;
        const startY = 1;
        
        this.maze[startX][startY] = 0;
        visited[startX][startY] = true;
        stack.push([startX, startY]);
        
        const directions = [
            [-2, 0], [2, 0], [0, -2], [0, 2]
        ];
        
        while (stack.length > 0) {
            const [x, y] = stack[stack.length - 1];
            const neighbors = [];
            
            for (const [dx, dy] of directions) {
                const nx = x + dx;
                const ny = y + dy;
                
                if (nx > 0 && nx < this.rows - 1 && 
                    ny > 0 && ny < this.cols - 1 && 
                    !visited[nx][ny]) {
                    neighbors.push([nx, ny, x + dx/2, y + dy/2]);
                }
            }
            
            if (neighbors.length > 0) {
                const [nx, ny, wallX, wallY] = neighbors[Math.floor(Math.random() * neighbors.length)];
                this.maze[nx][ny] = 0;
                this.maze[wallX][wallY] = 0;
                visited[nx][ny] = true;
                stack.push([nx, ny]);
            } else {
                stack.pop();
            }
        }
        
        // Ensure start and end are paths
        this.maze[this.start.x][this.start.y] = 0;
        this.maze[this.end.x][this.end.y] = 0;
        
        this.clearSolutions();
        this.renderMaze();
        
        this.solveDfsBtn.disabled = false;
        this.solveBfsBtn.disabled = false;
    }

    solveDFS() {
        this.dfsPath = [];
        this.dfsVisited = [];
        
        const visited = Array(this.rows).fill().map(() => Array(this.cols).fill(false));
        const path = [];
        const allVisited = [];
        
        const dfs = (x, y) => {
            if (x < 0 || x >= this.rows || y < 0 || y >= this.cols || 
                this.maze[x][y] === 1 || visited[x][y]) {
                return false;
            }
            
            visited[x][y] = true;
            path.push([x, y]);
            allVisited.push([x, y]);
            
            if (x === this.end.x && y === this.end.y) {
                return true;
            }
            
            const directions = [[0, 1], [1, 0], [0, -1], [-1, 0]];
            for (const [dx, dy] of directions) {
                if (dfs(x + dx, y + dy)) {
                    return true;
                }
            }
            
            path.pop();
            return false;
        };
        
        if (dfs(this.start.x, this.start.y)) {
            this.dfsPath = [...path];
            this.dfsVisited = [...allVisited];
            this.renderDFSSolution();
            this.updateDFSStats();
        }
        
        this.clearBtn.disabled = false;
    }

    solveBFS() {
        this.bfsPath = [];
        this.bfsVisited = [];
        
        const visited = Array(this.rows).fill().map(() => Array(this.cols).fill(false));
        const queue = [[this.start.x, this.start.y]];
        const parent = {};
        const allVisited = [];
        
        visited[this.start.x][this.start.y] = true;
        parent[`${this.start.x},${this.start.y}`] = null;
        
        const directions = [[0, 1], [1, 0], [0, -1], [-1, 0]];
        
        while (queue.length > 0) {
            const [x, y] = queue.shift();
            allVisited.push([x, y]);
            
            if (x === this.end.x && y === this.end.y) {
                // Reconstruct path
                const path = [];
                let current = `${x},${y}`;
                
                while (current !== null) {
                    const [cx, cy] = current.split(',').map(Number);
                    path.unshift([cx, cy]);
                    current = parent[current];
                }
                
                this.bfsPath = path;
                this.bfsVisited = allVisited;
                this.renderBFSSolution();
                this.updateBFSStats();
                break;
            }
            
            for (const [dx, dy] of directions) {
                const nx = x + dx;
                const ny = y + dy;
                
                if (nx >= 0 && nx < this.rows && ny >= 0 && ny < this.cols && 
                    this.maze[nx][ny] === 0 && !visited[nx][ny]) {
                    visited[nx][ny] = true;
                    queue.push([nx, ny]);
                    parent[`${nx},${ny}`] = `${x},${y}`;
                }
            }
        }
        
        this.clearBtn.disabled = false;
    }

    clearSolutions() {
        this.dfsPath = [];
        this.bfsPath = [];
        this.dfsVisited = [];
        this.bfsVisited = [];
        
        this.renderMaze();
        this.dfsDisplay.innerHTML = '';
        this.bfsDisplay.innerHTML = '';
        this.dfsStats.classList.add('hidden');
        this.bfsStats.classList.add('hidden');
        
        this.clearBtn.disabled = true;
    }

    renderMaze() {
        const mazeHtml = this.maze.map((row, i) => 
            row.map((cell, j) => {
                if (i === this.start.x && j === this.start.y) return 'S';
                if (i === this.end.x && j === this.end.y) return 'E';
                return cell === 1 ? '█' : '·';
            }).join('')
        ).join('\n');
        
        this.mazeDisplay.innerHTML = mazeHtml;
    }

    renderDFSSolution() {
        const pathSet = new Set(this.dfsPath.map(([x, y]) => `${x},${y}`));
        const visitedSet = new Set(this.dfsVisited.map(([x, y]) => `${x},${y}`));
        
        const mazeHtml = this.maze.map((row, i) => 
            row.map((cell, j) => {
                const key = `${i},${j}`;
                if (i === this.start.x && j === this.start.y) return 'S';
                if (i === this.end.x && j === this.end.y) return 'E';
                if (pathSet.has(key)) return '●';
                if (visitedSet.has(key)) return '○';
                return cell === 1 ? '█' : '·';
            }).join('')
        ).join('\n');
        
        this.dfsDisplay.innerHTML = mazeHtml;
    }

    renderBFSSolution() {
        const pathSet = new Set(this.bfsPath.map(([x, y]) => `${x},${y}`));
        const visitedSet = new Set(this.bfsVisited.map(([x, y]) => `${x},${y}`));
        
        const mazeHtml = this.maze.map((row, i) => 
            row.map((cell, j) => {
                const key = `${i},${j}`;
                if (i === this.start.x && j === this.start.y) return 'S';
                if (i === this.end.x && j === this.end.y) return 'E';
                if (pathSet.has(key)) return '●';
                if (visitedSet.has(key)) return '○';
                return cell === 1 ? '█' : '·';
            }).join('')
        ).join('\n');
        
        this.bfsDisplay.innerHTML = mazeHtml;
    }

    updateDFSStats() {
        document.getElementById('dfs-path-length').textContent = this.dfsPath.length;
        document.getElementById('dfs-cells-visited').textContent = this.dfsVisited.length;
        this.dfsStats.classList.remove('hidden');
    }

    updateBFSStats() {
        document.getElementById('bfs-path-length').textContent = this.bfsPath.length;
        document.getElementById('bfs-cells-visited').textContent = this.bfsVisited.length;
        this.bfsStats.classList.remove('hidden');
    }
}

// Enhanced maze rendering with better visualization
class MazeRenderer {
    constructor(mazeSolver) {
        this.solver = mazeSolver;
        this.setupEnhancedRendering();
    }

    setupEnhancedRendering() {
        // Override the render methods for better visualization
        this.solver.renderMaze = this.renderMazeEnhanced.bind(this);
        this.solver.renderDFSSolution = this.renderDFSSolutionEnhanced.bind(this);
        this.solver.renderBFSSolution = this.renderBFSSolutionEnhanced.bind(this);
    }

    renderMazeEnhanced() {
        const container = this.solver.mazeDisplay;
        container.innerHTML = '';
        
        const mazeGrid = document.createElement('div');
        mazeGrid.className = 'maze-content';
        
        for (let i = 0; i < this.solver.rows; i++) {
            const row = document.createElement('div');
            row.className = 'maze-row';
            
            for (let j = 0; j < this.solver.cols; j++) {
                const cell = document.createElement('span');
                cell.className = 'maze-cell';
                
                if (i === this.solver.start.x && j === this.solver.start.y) {
                    cell.textContent = 'S';
                    cell.classList.add('start');
                } else if (i === this.solver.end.x && j === this.solver.end.y) {
                    cell.textContent = 'E';
                    cell.classList.add('end');
                } else if (this.solver.maze[i][j] === 1) {
                    cell.textContent = '█';
                    cell.classList.add('wall');
                } else {
                    cell.textContent = '·';
                    cell.classList.add('path');
                }
                
                row.appendChild(cell);
            }
            
            mazeGrid.appendChild(row);
        }
        
        container.appendChild(mazeGrid);
        this.addLegend(container);
    }

    renderDFSSolutionEnhanced() {
        const container = this.solver.dfsDisplay;
        container.innerHTML = '';
        
        const pathSet = new Set(this.solver.dfsPath.map(([x, y]) => `${x},${y}`));
        const visitedSet = new Set(this.solver.dfsVisited.map(([x, y]) => `${x},${y}`));
        
        const mazeGrid = document.createElement('div');
        mazeGrid.className = 'maze-content';
        
        for (let i = 0; i < this.solver.rows; i++) {
            const row = document.createElement('div');
            row.className = 'maze-row';
            
            for (let j = 0; j < this.solver.cols; j++) {
                const cell = document.createElement('span');
                cell.className = 'maze-cell';
                const key = `${i},${j}`;
                
                if (i === this.solver.start.x && j === this.solver.start.y) {
                    cell.textContent = 'S';
                    cell.classList.add('start');
                } else if (i === this.solver.end.x && j === this.solver.end.y) {
                    cell.textContent = 'E';
                    cell.classList.add('end');
                } else if (pathSet.has(key)) {
                    cell.textContent = '●';
                    cell.classList.add('dfs-path');
                } else if (visitedSet.has(key)) {
                    cell.textContent = '○';
                    cell.classList.add('dfs-visited');
                } else if (this.solver.maze[i][j] === 1) {
                    cell.textContent = '█';
                    cell.classList.add('wall');
                } else {
                    cell.textContent = '·';
                    cell.classList.add('path');
                }
                
                row.appendChild(cell);
            }
            
            mazeGrid.appendChild(row);
        }
        
        container.appendChild(mazeGrid);
    }

    renderBFSSolutionEnhanced() {
        const container = this.solver.bfsDisplay;
        container.innerHTML = '';
        
        const pathSet = new Set(this.solver.bfsPath.map(([x, y]) => `${x},${y}`));
        const visitedSet = new Set(this.solver.bfsVisited.map(([x, y]) => `${x},${y}`));
        
        const mazeGrid = document.createElement('div');
        mazeGrid.className = 'maze-content';
        
        for (let i = 0; i < this.solver.rows; i++) {
            const row = document.createElement('div');
            row.className = 'maze-row';
            
            for (let j = 0; j < this.solver.cols; j++) {
                const cell = document.createElement('span');
                cell.className = 'maze-cell';
                const key = `${i},${j}`;
                
                if (i === this.solver.start.x && j === this.solver.start.y) {
                    cell.textContent = 'S';
                    cell.classList.add('start');
                } else if (i === this.solver.end.x && j === this.solver.end.y) {
                    cell.textContent = 'E';
                    cell.classList.add('end');
                } else if (pathSet.has(key)) {
                    cell.textContent = '●';
                    cell.classList.add('bfs-path');
                } else if (visitedSet.has(key)) {
                    cell.textContent = '○';
                    cell.classList.add('bfs-visited');
                } else if (this.solver.maze[i][j] === 1) {
                    cell.textContent = '█';
                    cell.classList.add('wall');
                } else {
                    cell.textContent = '·';
                    cell.classList.add('path');
                }
                
                row.appendChild(cell);
            }
            
            mazeGrid.appendChild(row);
        }
        
        container.appendChild(mazeGrid);
    }

    addLegend(container) {
        const legend = document.createElement('div');
        legend.className = 'maze-legend';
        
        const legendItems = [
            { class: 'start', symbol: 'S', label: 'Start' },
            { class: 'end', symbol: 'E', label: 'End' },
            { class: 'wall', symbol: '█', label: 'Wall' },
            { class: 'path', symbol: '·', label: 'Path' },
            { class: 'dfs-path', symbol: '●', label: 'DFS Path' },
            { class: 'bfs-path', symbol: '●', label: 'BFS Path' },
            { class: 'dfs-visited', symbol: '○', label: 'DFS Visited' },
            { class: 'bfs-visited', symbol: '○', label: 'BFS Visited' }
        ];
        
        legendItems.forEach(item => {
            const legendItem = document.createElement('div');
            legendItem.className = 'legend-item';
            
            const colorBox = document.createElement('div');
            colorBox.className = `legend-color ${item.class}`;
            colorBox.textContent = item.symbol;
            
            const label = document.createElement('span');
            label.textContent = item.label;
            
            legendItem.appendChild(colorBox);
            legendItem.appendChild(label);
            legend.appendChild(legendItem);
        });
        
        container.appendChild(legend);
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    const mazeSolver = new MazeSolver();
    const mazeRenderer = new MazeRenderer(mazeSolver);
    
    // Add some helpful console messages
    console.log('🔍 Maze Solver initialized!');
    console.log('🎯 Features: Random maze generation, DFS/BFS solving, algorithm comparison');
    console.log('📊 Click "Generate New Maze" to start exploring!');
});